import { ObjectKeyPipe } from './object-key.pipe';

describe('ObjectKeyPipe', () => {
  it('create an instance', () => {
    const pipe = new ObjectKeyPipe();
    expect(pipe).toBeTruthy();
  });
});
