import { TimeConvertPipe } from './time-convert.pipe';

describe('TimeConvertPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeConvertPipe();
    expect(pipe).toBeTruthy();
  });
});
