export const AppConfig = {
  production: false,
  environment: 'LOCAL',
  apiUrl: 'https://tracklyapp.appup.cloud'
};
