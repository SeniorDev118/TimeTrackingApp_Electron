export const AppConfig = {
  production: true,
  environment: 'PROD',
  apiUrl: 'https://tracklyapp.appup.cloud'
};
