"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var electron_1 = require("electron");
var ioHook = require("iohook");
var path = require("path");
var url = require("url");
var moment = require("moment");
var cron_1 = require("cron");
var node_notifier_1 = require("node-notifier");
var win, serve, size, isTrack, keyboardCount, mouseCount, timerHandlers, settingData;
var takeScreenshotEvent, createNewActivityEvent, trayControlEvent, tray, selectProjectEvent, controlEvent;
var hourCronjobHandler, trackingIntervalHandler, engagementIntervalHandler, checkTrackOnHandler;
var contextMenu, currentTaskId, currentProjectId, selectedTaskId, selectedProjectId, previousTimestamp;
var idleSettingTimeInMins, lastTrackTimestamp, idleTimeInMilliSecs, lastProjectTimestamp, lastEngagementPer;
var projectsDetail, selectedProject, menuTemplate;
var trackingTimeIntervalMins, engagementTimeIntervalMins;
lastTrackTimestamp = 0;
lastProjectTimestamp = 0;
idleTimeInMilliSecs = 0;
keyboardCount = 0;
mouseCount = 0;
lastEngagementPer = 0;
currentTaskId = -1;
currentProjectId = -1;
selectedTaskId = -1;
selectedProjectId = -1;
previousTimestamp = 0;
trackingTimeIntervalMins = 0;
engagementTimeIntervalMins = 0;
isTrack = false;
settingData = {};
projectsDetail = {};
selectedProject = {};
menuTemplate = [];
timerHandlers = [];
var args = process.argv.slice(1);
serve = args.some(function (val) { return val === '--serve'; });
function createWindow() {
    var electronScreen = electron_1.screen;
    size = electronScreen.getPrimaryDisplay().workAreaSize;
    // Create the browser window.
    win = new electron_1.BrowserWindow({
        // x: 0,
        // y: 0,
        // width: 1280,
        // height: 720,
        width: 472,
        height: 667,
        center: true,
        minWidth: 472,
        minHeight: 667,
        maxWidth: 472,
        maxHeight: 667,
        maximizable: false,
        minimizable: false
        // width: size.width,
        // height: size.height
    });
    if (serve) {
        require('electron-reload')(__dirname, {
            electron: require(__dirname + "/node_modules/electron")
        });
        win.loadURL('http://localhost:4200');
    }
    else {
        win.loadURL(url.format({
            pathname: path.join(__dirname, 'dist/index.html'),
            protocol: 'file:',
            slashes: true
        }));
    }
    createTrayMenu();
    initData();
    // win.webContents.openDevTools();
    // Emitted when the window is closed.
    win.on('closed', function () {
        // Dereference the window object, usually you would store window
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        // win.close();
        if (win) {
            win = null;
        }
    });
}
/**
 * init data
 */
function initData() {
    idleTimeInMilliSecs = 0;
    projectsDetail = {};
    // customNotify('Test', 'Test');
}
/**
 * notification function
 * @param title: notification title
 * @param message: notification message
 */
function customNotify(title, message) {
    node_notifier_1.notify({
        title: title,
        message: message
    }, function (err, res) {
    });
}
/**
 * update track
 * @param projectId: project id
 * @param taskId: task id
 * @param timestamp: timestamp
 * @param isScreenshot: taking screenshot flag
 */
function updateTracks(projectId, taskId, timestamp, isScreenshot) {
    if (isScreenshot === void 0) { isScreenshot = true; }
    if (isScreenshot) {
        takeScreenShots(taskId, trackingTimeIntervalMins * 60 * 1000, false);
    }
    var newActivity = createNewActivity(projectId, taskId, timestamp);
    createNewActivityEvent.sender.send('create-new-activity-reply', newActivity);
    console.log('---create activity---');
    console.log(newActivity);
    if (settingData['notify_me_screenshot']) {
        customNotify('Time Tracker', 'Screenshot taken');
    }
}
/**
 * create new activity
 * @param projectId: project id
 * @param taskId: task id
 * @param timestamp: timestamp
 */
function createNewActivity(projectId, taskId, timestamp) {
    var duration = Math.floor((timestamp - previousTimestamp) / 1000);
    if (duration > (trackingTimeIntervalMins * 60 - 3)) {
        duration = trackingTimeIntervalMins;
    }
    var status = (idleTimeInMilliSecs >= idleSettingTimeInMins * 60 * 1000) ? 'idle' : 'engaged';
    var newActivity = {
        status: status,
        project_id: projectId,
        task_id: taskId < 0 ? null : taskId,
        duration: duration,
        mode: 'AUTOMATIC',
        reason: 'task interval screenshot detail done',
        date: moment(new Date(timestamp)).format('YYYY-MM-DD HH:mm:ss'),
        from_time: moment(new Date(previousTimestamp)).format('YYYY-MM-DD HH:mm:ss'),
        to_time: moment(new Date(timestamp)).format('YYYY-MM-DD HH:mm:ss'),
        screenshot_urls: [],
        mouse_click_count: mouseCount,
        keyboard_count: keyboardCount
    };
    mouseCount = 0;
    keyboardCount = 0;
    previousTimestamp = timestamp;
    return newActivity;
}
/**
 * take screenshots of desktop from UI
 * @param during: interval between activities in mini-second
 * @param isImmediate: immediate proecss flag
 */
function takeScreenShots(taskId, during, isImmediate) {
    if (isImmediate === void 0) { isImmediate = false; }
    if (isImmediate) {
        takeScreenshotEvent.sender.send('take-screenshot-reply', taskId);
        return;
    }
    // take a screenshot in random
    console.log('--- start random screenshot ---');
    for (var index = 0; index < 3; index++) {
        var time = Math.random() * during;
        console.log('random time: ', time);
        timerHandlers[index] = setTimeout(function () {
            takeScreenshotEvent.sender.send('take-screenshot-reply', taskId);
        }, time);
    }
}
/**
 * clear screenshots intervals
 */
function clearScreenshotsIntervals() {
    for (var index = 0; index < 3; index++) {
        if (timerHandlers[index]) {
            clearInterval(timerHandlers[index]);
        }
    }
}
/**
 * clear tracking data
 */
function clearTrackData() {
    isTrack = false;
    mouseCount = 0;
    keyboardCount = 0;
    previousTimestamp = 0;
    currentTaskId = -1;
    currentProjectId = -1;
    selectedTaskId = -1;
    clearScreenshotsIntervals();
}
/**
 * check if current weekday is inside target ones
 * @param weekDayString: weekdays string
 */
function checkWeekday(weekDayString) {
    var currentWeekday = moment().isoWeekday();
    var defaultWeekDays = ['', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
    var weekDays = weekDayString.trim().toLowerCase().split(',');
    return (weekDays.indexOf(defaultWeekDays[currentWeekday]) > -1);
}
/**
 * check if current time is in track on time
 * @param startTime: start time
 * @param endTime: end time
 */
function checkTrackOnTime(startTime, endTime) {
    if (moment(new Date()).format('HH:mm:ss') >= startTime && moment(new Date()).format('HH:mm:ss') <= endTime) {
        return true;
    }
    return false;
}
/**
 * check track on status
 */
function checkTrackOnStatus() {
    if (settingData['untracked_for_in_min']) {
        if (checkTrackOnHandler) {
            clearInterval(checkTrackOnHandler);
        }
        var interval = parseInt(settingData['untracked_for_in_min'], 10) * 60 * 1000;
        checkTrackOnHandler = setInterval(function () {
            if (settingData['notify_me_track_on'] &&
                checkWeekday(settingData['track_on']) &&
                checkTrackOnTime(settingData['start_time'], settingData['end_time'])) {
                if (!isTrack) {
                    customNotify('Time Tracker', 'Rimnider: You\'re not tracking time.');
                }
            }
        }, interval);
    }
}
/**
 * calculate idle time
 */
function calcuateIdleTime() {
    if (lastTrackTimestamp !== 0) {
        var diffInMilliSecs = Math.abs(lastTrackTimestamp - Date.now());
        if (diffInMilliSecs >= idleSettingTimeInMins * 60 * 1000) { // idle setting time in a minute format
            idleTimeInMilliSecs += diffInMilliSecs;
        }
        lastTrackTimestamp = Date.now();
    }
}
/**
 * calculate engagement percentage
 */
function calculateEngagementPer() {
    var hourInMilliSeconds = 60 * 60 * 1000;
    return Math.abs((hourInMilliSeconds - idleTimeInMilliSecs) / hourInMilliSeconds * 100);
}
/**
 * create time intervals
 */
function createTimeIntervals() {
    // tracking cron job
    if (trackingTimeIntervalMins <= 0) {
        console.log('Tracking interval is less than 0');
        return;
    }
    if (trackingIntervalHandler) {
        clearInterval(trackingIntervalHandler);
    }
    var trackingIntervalInMiniSecs = parseInt(trackingTimeIntervalMins, 10) * 60 * 1000;
    console.log('trackingTimeIntervalMins: ', trackingTimeIntervalMins, trackingIntervalInMiniSecs);
    trackingIntervalHandler = setInterval(function () {
        console.log('tracking interval running:');
        if (isTrack) {
            // increase timer
            if (projectsDetail.hasOwnProperty(selectedProjectId)) {
                var current = Date.now();
                var diffInMilliSecs = current - lastProjectTimestamp;
                projectsDetail[selectedProjectId]['time'] += diffInMilliSecs;
                lastProjectTimestamp = current;
                updateTrayTitle();
            }
            updateTracks(currentProjectId, currentTaskId, Date.now());
        }
    }, trackingIntervalInMiniSecs);
    // engagement cron job
    if (engagementTimeIntervalMins <= 0) {
        console.log('Tracking interval is less than 0');
        return;
    }
    if (engagementIntervalHandler) {
        clearInterval(engagementIntervalHandler);
    }
    var egIntervalInMiniSecs = parseInt(engagementTimeIntervalMins, 10) * 60 * 1000;
    console.log('engagementTimeIntervalMins: ', engagementTimeIntervalMins, egIntervalInMiniSecs);
    engagementIntervalHandler = setInterval(function () {
        console.log('engagement interval running:');
        calcuateIdleTime();
    }, egIntervalInMiniSecs);
}
/**
 * convert seconds to hh:mm
 * @param secs: seconds
 */
function makeTrayTime(secs) {
    var hours = Math.floor(Math.floor(secs / 3600));
    var minutes = Math.floor(Math.floor((secs - (hours * 3600)) / 60));
    // const seconds = Math.floor((secs - ((secs * 3600) + (minutes * 60))) % 60);
    var dHours = (hours > 9 ? hours : '0' + hours);
    var dMins = (minutes > 9 ? minutes : '0' + minutes);
    return dHours + ':' + dMins;
}
/**
 * update tray title
 */
function updateTrayTitle() {
    if (projectsDetail && selectedProjectId && projectsDetail[selectedProjectId]) {
        var timeInMiniSecs = parseInt(projectsDetail[selectedProjectId]['time'], 10);
        var projectTimer = makeTrayTime(Math.floor(timeInMiniSecs / 1000));
        if (contextMenu && menuTemplate.length > 0) {
            menuTemplate[1].visible = true;
            menuTemplate[1].label = selectedProject['code'] + " " + projectTimer;
            contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
            tray.setContextMenu(contextMenu);
        }
    }
    else {
        if (contextMenu && menuTemplate.length > 0) {
            menuTemplate[1].visible = false;
            contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
            tray.setContextMenu(contextMenu);
        }
    }
}
/**
 * update engagement
 * @param engagementPer: engagement percentage?
 */
function updateEngagement(engagementPer) {
    var endHour = moment().format('hh a');
    var startHour = moment().subtract(1, 'hours').format('hh a');
    return "Engagement(" + startHour + " - " + endHour + ") " + engagementPer + "% " + (engagementPer - lastEngagementPer) + "%";
}
/**
 * create tray menu
 */
function createTrayMenu() {
    /**
     * Set tray icon
     */
    var iconPath = path.join(__dirname, 'tray.png');
    tray = new electron_1.Tray(iconPath);
    menuTemplate = [
        {
            label: updateEngagement(0)
        },
        {
            label: '',
            visible: false
        },
        {
            label: 'Timer is running',
            click: function () {
                if (currentProjectId >= 0 && trayControlEvent) {
                    trayControlEvent.sender.send('tray-icon-control-reply', {
                        status: 'stop',
                        taskId: currentTaskId,
                        projectId: currentProjectId
                    });
                }
            },
            icon: path.join(__dirname, 'pause.png'),
            visible: false
        },
        {
            label: 'Timer is paused',
            click: function () {
                if (selectedProjectId >= 0 && trayControlEvent) {
                    trayControlEvent.sender.send('tray-icon-control-reply', {
                        status: 'start',
                        taskId: selectedTaskId,
                        projectId: selectedProjectId
                    });
                }
            },
            icon: path.join(__dirname, 'play.png'),
            enabled: false
        },
        {
            label: 'Switch Projects'
        },
        {
            label: 'Add a note',
            click: function () {
                controlEvent.sender.send('control-event-reply', { type: 'note' });
            },
            enabled: false
        },
        {
            label: 'Open Dashboard',
            click: function () {
                electron_1.shell.openExternal('https://tracklyapp.appup.cloud/trackly/#/430/1587/dashboard');
            }
        },
        {
            label: 'Settings',
            click: function () {
                controlEvent.sender.send('control-event-reply', { type: 'setting' });
            }
        },
        {
            label: 'About Track.ly',
            click: function () {
                controlEvent.sender.send('control-event-reply', { type: 'about' });
            }
        },
        {
            label: 'Help',
            click: function () {
                controlEvent.sender.send('control-event-reply', { type: 'help' });
            }
        },
        {
            label: 'Check for updates',
            click: function () {
                controlEvent.sender.send('control-event-reply', { type: 'check' });
            }
        },
        {
            label: 'Sign out',
            click: function () {
                controlEvent.sender.send('control-event-reply', { type: 'signout' });
                menuTemplate[3].enabled = false;
            }
        },
        {
            label: 'Quit tracker',
            click: function () {
                if (win) {
                    win = null;
                }
                electron_1.app.quit();
            }
        }
    ];
    contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
    tray.setContextMenu(contextMenu);
    tray.setToolTip('Time Tracker');
}
/**
 * build project tray menu
 * @param projects: projects
 * @param tasks: tasks
 */
function buildProjectMenu(projects, tasks) {
    var projectSubMenu = [];
    if (projects.length > 0) {
        projectSubMenu = projects.map(function (project) {
            var projectTasks = [];
            for (var index = 0; index < tasks.length; index++) {
                if (parseInt(tasks[index]['project_id'], 10) === parseInt(project['id'], 10)) {
                    projectTasks.push({
                        id: project['id'] + '-' + tasks[index]['id'],
                        label: tasks[index]['description']
                    });
                }
            }
            return {
                id: project['id'],
                label: project['name'],
                submenu: projectTasks
            };
        });
    }
    return projectSubMenu;
}
/**
 * round number
 * @param value: value
 * @param ndec: dec
 */
function round(value, ndec) {
    var n = 10;
    for (var i = 1; i < ndec; i++) {
        n *= 10;
    }
    if (!ndec || ndec <= 0) {
        return Math.round(value);
    }
    else {
        return Math.round(value * n) / n;
    }
}
/**
 * destroy ipcMain listeners and cron job handler
 */
function destroyListners() {
    if (electron_1.ipcMain) {
        electron_1.ipcMain.removeAllListeners('get-current-ids');
        electron_1.ipcMain.removeAllListeners('get-selected-ids');
        electron_1.ipcMain.removeAllListeners('get-window-size');
        electron_1.ipcMain.removeAllListeners('take-screenshot');
        electron_1.ipcMain.removeAllListeners('select-task');
        electron_1.ipcMain.removeAllListeners('start-track');
        electron_1.ipcMain.removeAllListeners('stop-track');
        electron_1.ipcMain.removeAllListeners('create-new-activity');
        electron_1.ipcMain.removeAllListeners('tray-icon-control');
        electron_1.ipcMain.removeAllListeners('select-project');
        electron_1.ipcMain.removeAllListeners('control-event');
    }
    if (trackingIntervalHandler) {
        clearInterval(trackingIntervalHandler);
    }
    if (engagementIntervalHandler) {
        clearInterval(engagementIntervalHandler);
    }
    if (checkTrackOnHandler) {
        clearInterval(checkTrackOnHandler);
    }
    if (hourCronjobHandler) {
        hourCronjobHandler.stop();
    }
}
// function parseCookies (rc) {
//   var list = {};
//   rc && rc.split(';').forEach(function( cookie ) {
//     var parts = cookie.split('=');
//     list[parts.shift().trim()] = decodeURI(parts.join('='));
//   });
//   return list;
// }
try {
    // This method will be called when Electron has finished
    // initialization and is ready to create browser windows.
    // Some APIs can only be used after this event occurs.
    electron_1.app.on('ready', createWindow);
    // Quit when all windows are closed.
    electron_1.app.on('window-all-closed', function () {
        // On OS X it is common for applications and their menu bar
        // to stay active until the user quits explicitly with Cmd + Q
        // if (process.platform !== 'darwin') {
        // }
        electron_1.app.quit();
    });
    electron_1.app.on('activate', function () {
        // On OS X it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (win === null) {
            createWindow();
        }
    });
    electron_1.app.on('before-quit', function (evt) {
        if (tray) {
            tray.destroy();
            tray = null;
        }
        ioHook.stop();
        ioHook.unload();
        destroyListners();
    });
    /**
     * Cron Job for Engagement
     */
    hourCronjobHandler = new cron_1.CronJob('0 0 */1 * * *', function () {
        if (contextMenu && menuTemplate.length > 0) {
            console.log('engagement cronjob running:');
            var engagementPer = round(calculateEngagementPer(), 2);
            menuTemplate[0].label = updateEngagement(engagementPer);
            contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
            tray.setContextMenu(contextMenu);
            lastEngagementPer = engagementPer;
            idleTimeInMilliSecs = 0;
        }
        // check the reset time
        var currentTime = new Date();
        var currentHours = currentTime.getHours();
        var currentMinutes = currentTime.getMinutes();
        if (currentHours === 0 && currentMinutes === 0) {
            for (var key in projectsDetail) {
                if (projectsDetail.hasOwnProperty(key)) {
                    projectsDetail[key]['time'] = 0;
                }
            }
        }
    }, null, true);
    /**
     * ipcMain lisner to get current task id and project id
     */
    electron_1.ipcMain.on('get-current-ids', function (event, arg) {
        event.sender.send('get-current-ids-reply', {
            currentTaskId: currentTaskId,
            currentProjectId: currentProjectId
        });
    });
    /**
     * ipcMain lisner to get selected task id and project id
     */
    electron_1.ipcMain.on('get-selected-ids', function (event, arg) {
        event.sender.send('get-selected-ids-reply', {
            selectedTaskId: selectedTaskId,
            selectedProjectId: selectedProjectId
        });
    });
    /**
     * ipcMain lisner to get current desktop window size
     */
    electron_1.ipcMain.on('get-window-size', function (event, arg) {
        event.sender.send('get-window-size-reply', size);
    });
    /**
     * ipcMain lisner to get screenshot event
     */
    electron_1.ipcMain.on('take-screenshot', function (event, arg) {
        takeScreenshotEvent = event;
    });
    /**
     * ipcMain lisner to get control event
     */
    electron_1.ipcMain.on('control-event', function (event, arg) {
        controlEvent = event;
    });
    /**
     * ipcMain lisner to get task id selected
     */
    electron_1.ipcMain.on('select-task', function (event, arg) {
        if (currentProjectId < 0 && currentTaskId < 0) {
            selectedTaskId = parseInt(arg['taskId'], 10);
            selectedProjectId = parseInt(arg['projectId'], 10);
            event.sender.send('get-selected-ids-reply', {
                selectedTaskId: selectedTaskId,
                selectedProjectId: selectedProjectId
            });
            if (tray && menuTemplate.length > 0) {
                menuTemplate[2].visible = false;
                menuTemplate[3].visible = true;
                menuTemplate[3].enabled = true;
                contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
                tray.setContextMenu(contextMenu);
            }
        }
    });
    /**
     * ipcMain lisner to quit the app
     */
    electron_1.ipcMain.on('quit-app', function (event, arg) {
        if (win) {
            win = null;
        }
        electron_1.app.quit();
    });
    /**
     * ipcMain lisner to get start time tracking event
     */
    electron_1.ipcMain.on('start-track', function (event, arg) {
        if (currentTaskId >= 0 && currentProjectId >= 0) {
            if (currentTaskId !== arg['taskId'] || currentProjectId !== arg['projectId']) {
                isTrack = false;
                if (tray && menuTemplate.length > 0) {
                    menuTemplate[2].visible = false;
                    menuTemplate[3].visible = true;
                    menuTemplate[3].enabled = true;
                    contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
                    tray.setContextMenu(contextMenu);
                }
                updateTracks(currentProjectId, currentTaskId, Date.now(), false);
                clearTrackData();
            }
        }
        isTrack = true;
        lastTrackTimestamp = Date.now();
        if (tray && menuTemplate.length) {
            menuTemplate[2].visible = true;
            menuTemplate[3].visible = false;
            contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
            tray.setContextMenu(contextMenu);
        }
        currentTaskId = arg['taskId'];
        selectedTaskId = arg['taskId'];
        currentProjectId = arg['projectId'];
        selectedProjectId = arg['projectId'];
        previousTimestamp = Date.now();
        takeScreenShots(currentTaskId, trackingTimeIntervalMins * 60 * 1000, true);
        event.sender.send('start-track-reply', {
            currentTaskId: currentTaskId,
            currentProjectId: currentProjectId,
            selectedTaskId: selectedTaskId,
            selectedProjectId: selectedProjectId
        });
    });
    /**
     * ipcMain lisner to get stop time tracking event
     */
    electron_1.ipcMain.on('stop-track', function (event, arg) {
        if (isTrack) {
            updateTracks(arg['projectId'], arg['taskId'], Date.now(), false);
            clearTrackData();
            if (tray && menuTemplate.length > 0) {
                menuTemplate[2].visible = false;
                menuTemplate[3].visible = true;
                contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
                tray.setContextMenu(contextMenu);
            }
            event.sender.send('stop-track-reply', {
                currentTaskId: currentTaskId,
                currentProjectId: currentProjectId,
                selectedTaskId: selectedTaskId,
                selectedProjectId: selectedProjectId
            });
        }
    });
    /**
     * ipcMain lisner to update setting
     */
    electron_1.ipcMain.on('update-setting', function (event, arg) {
        settingData = arg['setting'];
        checkTrackOnStatus();
    });
    /**
     * ipcMain lisner to select project
     */
    electron_1.ipcMain.on('select-project', function (event, arg) {
        var current = Date.now();
        selectProjectEvent = event;
        selectedProject = arg['project'];
        if (selectedProject['id']) { // if project is selected
            selectedProjectId = selectedProject['id'];
            idleSettingTimeInMins = selectedProject['ideal_time_interval_mins'] ? parseInt(selectedProject['ideal_time_interval_mins'], 10) : 0;
            trackingTimeIntervalMins = selectedProject['time_interval_mins'] ? parseInt(selectedProject['time_interval_mins'], 10) : 0;
            engagementTimeIntervalMins = selectedProject['engagement_interval_mins'] ?
                parseInt(selectedProject['engagement_interval_mins'], 10) : 0;
            createTimeIntervals();
            lastProjectTimestamp = current;
            if (tray && menuTemplate.length > 0) {
                menuTemplate[2].visible = false;
                menuTemplate[3].visible = true;
                menuTemplate[3].enabled = true;
                contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
                tray.setContextMenu(contextMenu);
            }
            updateTrayTitle();
        }
        else { // if any project is not selected
            if (isTrack &&
                Object.keys(selectedProject).length !== 0 &&
                selectedProject['id'] &&
                projectsDetail.hasOwnProperty(selectedProject['id'])) { // if there is previous selected project
                var diffInMilliSecs = current - lastProjectTimestamp;
                projectsDetail[selectedProject['id']]['time'] += diffInMilliSecs;
            }
            selectedProject = {};
            selectedProjectId = -1;
            if (tray) {
                if (tray && menuTemplate.length > 0 && !isTrack) {
                    menuTemplate[1].visible = false;
                    menuTemplate[2].visible = false;
                    menuTemplate[3].visible = true;
                    menuTemplate[3].enabled = false;
                    contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
                    tray.setContextMenu(contextMenu);
                }
            }
        }
    });
    /**
     * ipcMain lisner to get all projects and tasks
     */
    electron_1.ipcMain.on('get-all-projects-tasks', function (event, arg) {
        if (arg['projects'] && arg['projects'].length > 0) {
            for (var index = 0; index < arg['projects'].length; index++) {
                if (arg['projects'][index] && arg['projects'][index]['id']) {
                    if (!projectsDetail.hasOwnProperty(arg['projects'][index]['id'])) {
                        projectsDetail[arg['projects'][index]['id']] = {
                            time: 0
                        };
                    }
                }
            }
            var projectSubMenu = buildProjectMenu(arg['projects'], arg['tasks']);
            if (tray && menuTemplate.length > 3) {
                menuTemplate[4].submenu = projectSubMenu;
                contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
                tray.setContextMenu(contextMenu);
            }
        }
    });
    /**
     * ipcMain activity lisner
     */
    electron_1.ipcMain.on('activity-notification', function (event, arg) {
        if (tray && menuTemplate.length > 0) {
            menuTemplate[5].enabled = true;
            contextMenu = electron_1.Menu.buildFromTemplate(menuTemplate);
            tray.setContextMenu(contextMenu);
        }
    });
    /**
     * ipcMain lisner to get event of tray icon control
     */
    electron_1.ipcMain.on('tray-icon-control', function (event, arg) {
        trayControlEvent = event;
    });
    /**
     * ipcMain lisner to get event of new activity creation
     */
    electron_1.ipcMain.on('create-new-activity', function (event, arg) {
        createNewActivityEvent = event;
    });
    /**
     * ioHook listener to get key down event
     */
    ioHook.on('keydown', function (event) {
        if (isTrack) {
            keyboardCount++;
            lastTrackTimestamp = Date.now();
        }
    });
    /**
     * ioHook listener to get mouse down event
     */
    ioHook.on('mousedown', function (event) {
        if (isTrack) {
            mouseCount++;
            lastTrackTimestamp = Date.now();
        }
    });
    // Register and start hook
    ioHook.start(false);
}
catch (e) {
    console.log('error: ', e);
    // Catch Error
    // throw e;
}
//# sourceMappingURL=main.js.map